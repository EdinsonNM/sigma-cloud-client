module.exports = {
    "verbose": false,
    "plugins": {
        "local": {
          "browsers": ["chrome"] // , "firefox"
      }
    //   istanbul: {
    //     dir: "./coverage",
    //     reporters: ["text-summary", "lcov"],
    //     include: [
    //       "/src/*.js"
    //     ],
    //     exclude: [
    //     ]
    //   }
    }
};
